var searchData=
[
  ['fluxo_80',['Fluxo',['../class_fluxo.html#a6bded64c2480ebaf84934b862f8add36',1,'Fluxo::Fluxo()'],['../class_fluxo.html#a74dcd470946256a473fcac34b8197161',1,'Fluxo::Fluxo(string, Sistema *, Sistema *)'],['../class_fluxo.html#a20505edd4a2d4103c6e005c6bf97ed23',1,'Fluxo::Fluxo(string, Sistema *, Sistema *, double)']]]
];
