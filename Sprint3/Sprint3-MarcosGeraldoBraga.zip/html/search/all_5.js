var searchData=
[
  ['getciclos_14',['getCiclos',['../class_modelo.html#a5a2267b1c6e786f7c1fc3e7436d1ca5d',1,'Modelo']]],
  ['getciclosatuais_15',['getCiclosAtuais',['../class_modelo.html#a643139217befd48c8d7279ba5b16eec7',1,'Modelo']]],
  ['getconteudo_16',['getConteudo',['../class_sistema.html#aac0953482039fe48782c09fe21f0f4ab',1,'Sistema']]],
  ['getdestino_17',['getDestino',['../class_fluxo.html#ae24fd783f11f0b7dde1372071e8d4bc2',1,'Fluxo']]],
  ['getfluxo_18',['getFluxo',['../class_fluxo.html#ac489179cf11e99f830ea0965ab80d95e',1,'Fluxo']]],
  ['getnome_19',['getNome',['../class_fluxo.html#a45e12976ddcf2ad4ef468f3131e22f41',1,'Fluxo::getNome()'],['../class_modelo.html#a9b6dbaff9a338a538541efc1dbe56805',1,'Modelo::getNome()'],['../class_sistema.html#a2a9cc94c796c7bc799f8f954367bbb54',1,'Sistema::getNome()']]],
  ['getorigem_20',['getOrigem',['../class_fluxo.html#a61d7665229f1880963cd666c033a71d1',1,'Fluxo']]]
];
