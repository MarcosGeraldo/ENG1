var searchData=
[
  ['incrementaciclo_21',['incrementaCiclo',['../class_modelo.html#a4b242d5673371402d683ed40982d4bfb',1,'Modelo']]],
  ['incrementaconteudo_22',['incrementaConteudo',['../class_sistema.html#acea240ef7777567028a0bccba6a23bd2',1,'Sistema']]]
];
