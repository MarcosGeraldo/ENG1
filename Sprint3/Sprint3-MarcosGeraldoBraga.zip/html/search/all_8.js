var searchData=
[
  ['nome_30',['nome',['../class_fluxo.html#a32ed818685963c0a0318071665774dde',1,'Fluxo::nome()'],['../class_modelo.html#a8186e8e88997c62d23b8bfb5feafd959',1,'Modelo::nome()'],['../class_sistema.html#afc23ce8b81eb7b84a7fb870cefcecb70',1,'Sistema::nome()']]]
];
