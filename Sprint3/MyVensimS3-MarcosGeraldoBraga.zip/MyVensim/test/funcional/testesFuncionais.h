#ifndef TESTE_FUNCIONAL_H
#define TESTE_FUNCIONAL_H

/**
*@brief Esta funcao executa o teste funcial exponencial
*/
void testeExponencialFuncional();
/**
*@brief Esta funcao executa o teste logistico
*/
void testeLogisticaFuncional();
/**
*@brief Esta funcao executa o teste "complexo", que possui varios sistemas e fluxos
*/
void testeComplexoFuncional();


#endif
