#ifndef TESTE_UNITARIO_H
#define TESTE_UNITARIO_H


/**
*@brief Esta funcao faz o teste unitario do Fluxo
*/
void testeDoFluxo();
/**
*@brief Esta funcao faz o teste unitario do Modelo
*/
void testeDoModelo();
/**
*@brief Esta funcao faz o teste unitario do Sistema
*/
void testeDoSistema();




#endif
