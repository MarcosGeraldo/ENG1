#ifndef TESTE_FUNCIONAL_H
#define TESTE_FUNCIONAL_H


void testeExponencialFuncional();
void testeLogisticaFuncional();
void testeComplexoFuncional();


#endif
