#include <iostream>
#include "testesFuncionais.h"

using namespace std;


int main(){

  cout << "\nInicio dos testes funcionais!!!";

  testeExponencialFuncional();
	testeLogisticaFuncional();
	testeComplexoFuncional();

  cout << "\nInicio dos testes funcionais!!!";

  return 0;
}
