#ifndef TESTE_UNITARIO_H
#define TESTE_UNITARIO_H

void testeDoFluxo();
void testeDoModelo();
void testeDoSistema();




#endif
