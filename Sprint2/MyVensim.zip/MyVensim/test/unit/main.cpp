#include <iostream>
#include "testesUnitarios.h"

using namespace std;


int main(){

  cout << "\nInicio dos testes unitarios!!!";

  testeDoFluxo();
	testeDoSistema();
	testeDoModelo();

  cout << "\nInicio dos testes unitarios!!!";

  return 0;
}
