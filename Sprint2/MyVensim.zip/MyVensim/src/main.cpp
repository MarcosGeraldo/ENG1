#include <iostream>

#include "../../src/lib/modelo.h"
#include "../../src/lib/sistema.h"
#include "../../src/lib/fluxo.h"

int main()
{

    cout <<"\nMain Principal\n";
    return 0;
}
